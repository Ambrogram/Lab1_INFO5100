package my_project.src.main.java.edu.neu.mgen;

public class Firstjavaprogram {
    public static void main(String[] args) {
        System.out.println("It is my first Java program");
    }
}
