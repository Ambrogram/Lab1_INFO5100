package edu.neu;

public class test {
    public static void main(String[] args) {
        //System.out.println('A' + 'B');
        int i = 0 ;
        while(i < 5)
        {
             System.out.println("Hello");
            i++;
        }
       

    }
    
}

